
function XYZW=cub_gausscheb_tens3D(deg)

card_gs=ceil((deg+1)/2);

[x,w]=gauss_cheb(card_gs);

[X,Y,Z]=ndgrid(x); 
[WX,WY,WZ]=ndgrid(w);

XYZW=[X(:) Y(:) Z(:) (WX(:)).*(WY(:)).*(WZ(:))];







function [x,w]=gauss_cheb(deg)

% https://en.wikipedia.org/wiki/Chebyshev%E2%80%93Gauss_quadrature

i=1:deg;
x=cos((2*i'-1)*pi/(2*deg));
w=(pi/deg)*ones(size(x));


