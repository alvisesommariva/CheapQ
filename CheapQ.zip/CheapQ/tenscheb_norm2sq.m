
function [coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,...
    chebyshev_indices)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% Input:
%
% ade: total degree of the basis.
% 
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j k]" then the s-th polynomial is
%                       phi_s(x,y,z)=T_i(x) T_j(y) T_k(z)
%       where T_m(u)=cos(m*acos(u)).
%
%-----------------------------------------------------------------------
% Output:
%
% coeffs: computation of (phi_k,phi_k) where phi_k is the k-th tensor
%         product polynomial of the basis used in the Vandermonde matrix.
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j k]" then the s-th polynomial is
%                       T_i(x) T_j(y) T_k(z)
%       where T_m(u)=cos(m*acos(u)).
%-----------------------------------------------------------------------

if nargin < 2
    d=3;
    N = nchoosek(ade+d,d); chebyshev_indices = zeros(N,3);
    for i=2:N
        chebyshev_indices(i,:) = mono_next_grlex(d,...
            chebyshev_indices(i-1,:));
    end
end

coeffs=[];
for k=1:size(chebyshev_indices,1)
    coeffsL=pi^3/2^sum(not(chebyshev_indices(k,:) == 0));
    coeffs=[coeffs; coeffsL];
end
