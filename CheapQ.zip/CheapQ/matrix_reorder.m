
function matrix_reorder

T =[1.061933819992880e+00     1.417982244585294e+00
    1      2
     8.032594153918297e-01     1.535064382881341e+00
     8.119338199928796e-01     1.378386134504159e+00
     9.000000000000000e-01     8.900000000000000e-01
     1.4 1.2];

PSH=polyshape(T);
tri=triangulation(PSH);

T1=tri.Points
T1CL=tri.ConnectivityList;

permL=[];

for k=1:size(T,1)
    TL=T(k,:);
    for j=1:size(T1,1)
        flag=isequal(TL,T1(j,:));
        if flag == 1, fprintf('\n k: %3.0f j: %3.0f',k,j); 
            permL=[permL; j k];
            break;
        end
    end
end

[res,ipermL]=sort(permL(:,1));
permL=permL(ipermL,:);

TR=[];
for k=1:size(T1CL,1)
    rowsL=T1CL(k,:);
    TRL=permL(rowsL',2);
    TR=[TR; TRL'];
end

TR

fprintf('\n')




