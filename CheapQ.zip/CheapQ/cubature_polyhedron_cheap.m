
function [XYZW,XYZW_tens_ref,chebyshev_indices,V_ref]=...
    cubature_polyhedron_cheap(vertices,facets,ade,XYZW_tens_ref,...
    chebyshev_indices,V_ref,coeffs)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% This routine computes nodes and weights of a cubature formula with degree
% of precision "ade" on a polyhedron defined by "vertices" and "facets".
%
% The formula is defined by nodes in the bounding box (so not necessarily
% belonging to the domain) and possibly negative weights.
% In spite of that the formula is stable since the condition number of the
% integration is bounded.
%-----------------------------------------------------------------------
% Input:
%-----------------------------------------------------------------------
% vertices: The vertices are stored in "vertices" and is an "m x 3" matrix.
%  The k-th vertex has coordinates "vertices(k,:)".
%
% facets: The variable "facets" can be:
%
% 1. A "cell array":
%    In this case the i-th cell is a vector of positive integers,
%    representing the indices of vertices of the i-th facet, taking into
%    account the variable "vertices". The orientation of the facet is
%    counterclockwise (w.r.t to outward normal).
%
% 2. A "matrix" with dimension "m x 3":
%    In this case the i-th row is a vector of positive integers,
%    representing the indices of vertices of the triangular facet, taking
%    into account the variable "vertices". The orientation of the
%    triangular facet is counterclockwise (w.r.t to outward normal).
%
% ade: algebraic degree of precision of the rule (total degree).
%
% * XYZW_tens_ref: precomputed nodes and weights of a tensorial rule, in  
%    the domain [-1,1]^3. The first three columns represent the coordinates 
%    of the nodes, the last column the respective weights.
%    Thus x=XYZW_tens_ref(:,1), y=XYZW_tens_ref(:,2), z=XYZW_tens_ref(:,3)
%    and w=XYZW_tens_ref(:,4) define a rule with nodes (x,y,z) and weights
%    "w".
%
% * chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j k]" then the s-th polynomial is
%                       T_i(x) T_j(y) T_k(z)
%       where T_m(u)=cos(m*acos(u)).
% 
% * V_ref: Vandermonde matrix of the pointset "XYZW_tens_ref(:,1:3)", w.r.t.
%    a certain tensorial polynomial basis of Chebyshev type. It is defined
%    by the routine "dCHEBVAND".
%
% * coeffs:
%
% Note: The variables in which there is an asterisk are not mandatory.
%-----------------------------------------------------------------------
% Output:
%-----------------------------------------------------------------------
% XYZW: The variable "XYZW" is a matrix with "m" rows (that is the
%  cardinality of the cubature pointset) and 4 columns.
%  The first 3 columns are the coordinates of the nodes of a
%  rule over the polyhedron, while the 4th column represent the
%  corresponding weights.
%
% XYZW_tens_ref: precomputed nodes and weights of a tensorial rule, in the 
%    domain [-1,1]^3. The first three columns represent the coordinates of
%    the nodes, the last column the respective weights.
%    Thus x=XYZW_tens_ref(:,1), y=XYZW_tens_ref(:,2), z=XYZW_tens_ref(:,3)
%    and w=XYZW_tens_ref(:,4) define a rule with nodes (x,y,z) and weights
%    "w".
%
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
% by the routine "tenscheb_norm2sq".
% 
% V_ref: Vandermonde matrix of the pointset "XYZW_tens_ref(:,1:3)", w.r.t.
%    a certain tensorial polynomial basis of Chebyshev type. It is defined
%    by the routine "dCHEBVAND".
%-----------------------------------------------------------------------
% Routines called directly by "cubature_polyhedron_cheap_001":
%
% 1. cub_gausscheb_tens3D (external)
% 2. mono_next_grlex (external)
% 3. dCHEBVAND (external)
% 4. tenscheb_norm2sq (external)
% 5. scale_rule (attached)
% 6. chebyshev_moments_polyhedron (attached)
%-----------------------------------------------------------------------
% Data:
% First version: January 11, 2025.
% Latest version: February 4, 2025.
%-----------------------------------------------------------------------

% ........................... TROUBLESHOOTING  .........................

if nargin < 4
    XYZW_tens_ref=cub_gausscheb_tens3D(2*ade);
end

if nargin < 5
    d=3;
    N = nchoosek(ade+d,d); chebyshev_indices = zeros(N,3);
    for i=2:N
        chebyshev_indices(i,:) = mono_next_grlex(d,...
            chebyshev_indices(i-1,:));
    end
end

if nargin < 6
    dboxU=[-1 -1 -1; 1 1 1];
    X=XYZW_tens_ref(:,1:3);
    V_ref = dCHEBVAND(ade,X,dboxU,chebyshev_indices);
end


% ........................... (phi_k,phi_k) ...........................
if nargin < 7
[coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,chebyshev_indices);
end

% ........................... COMPUTE MOMENTS ..........................
moments_ch=chebyshev_moments_polyhedron(vertices,facets,ade,...
    [],chebyshev_indices);

dbox(1)=min(vertices(:,1)); dbox(2)=max(vertices(:,1));
dbox(3)=min(vertices(:,2)); dbox(4)=max(vertices(:,2));
dbox(5)=min(vertices(:,3)); dbox(6)=max(vertices(:,3));
XYZW_tens=scale_rule(XYZW_tens_ref,dbox);
w1=XYZW_tens(:,4);
w2=V_ref*(moments_ch./coeffs);

W=w1.*w2;

XYZW=[XYZW_tens(:,1:3) W];









function XYZW_tens=scale_rule(XYZW_tens_ref,dbox)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% Scale reference nodes from [-1,1]^3 to the bounding box.
%
% Note:
% For the needs of the routine it is not required to scale also the
% weights.
%-----------------------------------------------------------------------

a=dbox(1); b=dbox(2);
X=XYZW_tens_ref(:,1);
X=(a+b)/2 + ((b-a)/2)*X;

a=dbox(3); b=dbox(4);
Y=XYZW_tens_ref(:,2);
Y=(a+b)/2 + ((b-a)/2)*Y;

a=dbox(5); b=dbox(6);
Z=XYZW_tens_ref(:,3);
Z=(a+b)/2 + ((b-a)/2)*Z;

W=XYZW_tens_ref(:,4);

XYZW_tens=[X Y Z W];









function moments=chebyshev_moments_polyhedron(vertices,facets,ade,...
    normals,chebyshev_indices)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% Compute the moments "moments" of the chebyshev basis
%                         T_i(x)*T_j(y)*T_k(z)
% with i+j+k <= ade, over the polyhedron with vertices "vertices", whose
% polygonal facets are described by "facets".
%-----------------------------------------------------------------------
% Input:
%-----------------------------------------------------------------------
% vertices: The vertices are stored in "vertices" and is an "m x 3" matrix.
% The k-th vertex has coordinates "vertices(k,:)".
%
% facets: The variable "facets" can be:
%
% 1. A "cell array":
%    In this case the i-th cell is a vector of positive integers,
%    representing the indices of vertices of the i-th facet, taking into
%    account the variable "vertices". The orientation of the facet is
%    counterclockwise (w.r.t to outward normal).
%
% 2. A "matrix" with dimension "m x 3":
%    In this case the i-th row is a vector of positive integers,
%    representing the indices of vertices of the triangular facet, taking
%    into account the variable "vertices". The orientation of the
%    triangular facet is counterclockwise (w.r.t to outward normal).
%
% If facets normals are available they are stored in the matrix "normals".
% The k-th row contains the normal of the k-th facet.
%
% ade: algebraic (total) degree of precision of the rule.
%
% normals: normals to the facets.
%-----------------------------------------------------------------------
% Output:
%-----------------------------------------------------------------------
% moments: moments of the chebyshev basis
%                         T_i(x)*T_j(y)*T_k(z)
% with i+j+k <= ade, over the polyhedron with vertices "vertices", whose
% polygonal facets are described by "facets".
%-----------------------------------------------------------------------
% Reference:
% [1] E.B. Chin, J.B. Lasserre, N. Sukumar:
% "Numerical integration of homogeneous function on convex and nonconvex
% polygons and polyhedra".
% Computational Mechanics, Vol. 56, No. 6, pp 967?981.
% https://doi.org/10.1007/s00466-015-1213-7
%
% See also references therein.
%-----------------------------------------------------------------------
% Data:
% Revised: February 16, 2021.
%-----------------------------------------------------------------------


%-----------------------------------------------------------------------
% Chebyshev indices.
%
% Since we have to compute the cubature of a basis of tensorial Chebyshev
% polynomials of total degree up to "ade", we have to provide an order to
% the Chebyshev indices.
%
% More in detail, they are of the form
%                  "(T_i(x))*(T_j(y))*(T_k(z))"
% and we order such triples (i,j,k).
%-----------------------------------------------------------------------

tf = iscell(facets);
number_of_facets=length(facets);



%-----------------------------------------------------------------------
% Computing hyperrectangle with sides parallel to the x, y, z axis.
%
% Active vertices in computations. In case one uses alphashape, some
% vertices may not be used.
%-----------------------------------------------------------------------

ii=unique(facets(:));

dbox(1)=min(vertices(ii,1)); dbox(2)=max(vertices(ii,1));
dbox(3)=min(vertices(ii,2)); dbox(4)=max(vertices(ii,2));
dbox(5)=min(vertices(ii,3)); dbox(6)=max(vertices(ii,3));



%-----------------------------------------------------------------------
% Computing moments "chebyshev_moms" on polyhedron facets.
% The moments are ordered following "chebyshev_indices" to determine the
% m-th polynomial to be considered.
% The matrix "chebyshev_moms" has "number_of_facets" columns and the
% dimension of the polynomial space of total degree "ade" as number of rows.
%
% In other words "chebyshev_moms(ii,jj)" is the moment of the "ii"-th
% chebyshev basis on the "jj"-th facet.
%-----------------------------------------------------------------------

chebyshev_moms=[];
for k=1:number_of_facets

    % Row vector of indices of vertices describing the k-th facet
    if tf == 1 % facets are stored in cells
        facetL=facets{k};
    else % facets are stored in m x 3 matrix (triangular facets)
        facetL=facets(k,:);
    end


    % Vertices of the facet ordered counterclockwise w.r.t. the outward
    % normal.
    XV=vertices(facetL',1);
    YV=vertices(facetL',2);
    ZV=vertices(facetL',3);


    % Cubature rule over facet. Storing in "n" the normal to the facet.
    if nargin < 4
        [XYZW,n,pgonL,triL]=cubature_facet_formula(XV,YV,ZV,ade+1);
    else
        if size(normals,1) == 0
            [XYZW,n,pgonL,triL]=cubature_facet_formula(XV,YV,ZV,ade+1);
        else
            [XYZW,pgonL,triL]=cubature_facet_formula(XV,YV,ZV,ade+1);
            n=normals(k,:);
        end
    end

    [xv0,yv0,zv0,R10,RFM]=maptopolygon2(XV,YV,ZV);
    [xv03,yv03,zv03,n]=maptopolygon3(xv0,yv0,zv0,R10,RFM);

    nodes=XYZW(:,1:3); weights=XYZW(:,4);


    chebyshev_moms_facet=cubature_tens_chebyshev_facet_V(nodes,weights,...
        chebyshev_indices,dbox);



    % Note:
    % The factor n(1) comes out from the divergence theorem applied to the
    % vector field V=(f,0,0) where f is the x-primitive of the
    % tensorial-Chebyshev polynomial of which one wants to compute the
    % moment.


    chebyshev_moms=[chebyshev_moms n(1)*chebyshev_moms_facet];

end

%-----------------------------------------------------------------------
% Computing moments "moments" on polyhedron by summing contributions on the
% facets.
% See reference [1], formula (7).
%-----------------------------------------------------------------------

moments=sum(chebyshev_moms,2);









function [XYZW,n,pgon,tri]=cubature_facet_formula(XV,YV,ZV,ade)

%-----------------------------------------------------------------------
% OBJECT:
% This routine computes a cubature rule of algebraic degree of exactness
% equal to "ade" on the polygon in 3D whose vertices are (XV,YV,ZV).
% As output we have a matrix "XYZW" with "m" rows and "4" columns.
% The nodes are the rows of "XYZW(:,1:3)", while the weights are
% "XYZW(:,4)".
%
% n is the outer normal vector to the facet of the polyhedron, supposed
% that the vertices are oriented counterclockwise in its respect.
%
% Note: differently from classical codes on polygons, the first and
% last vertex must NOT be equal, i.e. the points [XV(1) YV(1) ZV(1)] and
% [XV(end) YV(end) ZV(end)] must not be equal.
%-----------------------------------------------------------------------

% Rototranslation map to a certain 2D polygon
[xv0,yv0,zv0,R10,RFM]=maptopolygon2(XV,YV,ZV);

% Cubature over a certain 2D polygon.
pgon=[];
tri=[];

if length(xv0) > 3
    xyw=polygauss_2018(ade,xv0,yv0);
    % xyw=polygauss_2013(ade,[xv0 yv0]);
else
    [~,xyw_bar]=cubature_triangle(ade);
    xyw=rule_conversion(xyw_bar,[xv0 yv0]);
end

xv_cub=xyw(:,1); yv_cub=xyw(:,2); zw_cub=zv0(1)*ones(size(yv_cub));

% Map it back to obtain a cubature rule over the 3D polygon.
[XV_CUB,YV_CUB,ZV_CUB,n]=maptopolygon3(xv_cub,yv_cub,zw_cub,R10,RFM);
WV_CUB=xyw(:,3);

% Assembly the rule as a certain matrix.
XYZW=[XV_CUB YV_CUB ZV_CUB WV_CUB];









function area_triangle=area_triangular_facet(XV,YV,ZV)

% This routine computes the area of a triangular facet with vertices 
% (XV,YV,ZV).

% AREA OF A TRIANGLE IN 3D VIA ERONE'S RULE.

A=[XV(1) YV(1) ZV(1)];
B=[XV(2) YV(2) ZV(2)];
C=[XV(3) YV(3) ZV(3)];

c=norm(B-A); a=norm(C-B); b=norm(C-A);
p=(a+b+c)/2;

% Erone formula.
area_triangle=sqrt(p*(p-a)*(p-b)*(p-c));









function [xv,yv,zv,R10,RFM,abcd]=maptopolygon2(XV,YV,ZV)

%-----------------------------------------------------------------------
% Object:
% This routine takes a polygon in the 3D space whose vertices are (XV,YV,ZV)
% and maps it to a flat polygon with vertices (xv,yv,0) by a "rigid
% motion".
% The vector "zv" and the rotation matrix "R10" allow to pull back the
% points.
%-----------------------------------------------------------------------
% Input:
%
% XV,YV,ZV: coordinates of the vertices of a polygon in the three
% dimensional space (e.g. the vertices of a facet of a tetrahedra); last
% vertex may not be repeated.
%-----------------------------------------------------------------------
% Output:
%
% xv,yv: coordinates of the vertices of a polygon in the two
% dimensional space that is obtained by a "rigid motion" of a polygon with
% vertices (XV,YV,ZV); last vertex may not be repeated.
%
% zv, R10: the polygon P with coordinates (xv,yv,0) is
%          (R10*[XV'; YV'; ZV'])'-[0V 0V ZV]
%     where 0V is the null vector with the same dimension of ZV.
%
% R10,RFM: rotation and reflection matrices involved in the process.
%     It is "P=R10'*(RFM*P2+PS)" where "PS" is a certain shift, "P2" a
%     the plane xy and "P" is a point in the 3D plane.
%
% abcd: vector whose components [a b c d] determine the equation of the
%     plane "a*x+b*y+c*z+d=0" containing the vertices of the polygon.
%
%-----------------------------------------------------------------------

% Determine the needed rigid motion. We map A in 0, B in a point with
% coordinates (dist(A,B),0,0) and the versor of the normal into (0,0,1).

A=[XV(1) YV(1) ZV(1)]; A=A';
B=[XV(2) YV(2) ZV(2)]; B=B';
C=[XV(3) YV(3) ZV(3)]; C=C';

% Equation of the plane containing the facets.
% See e.g.:
% https://math.stackexchange.com/questions/2686606/equation-of-a-plane-
% passing-through-3-points
n=cross(B-A,C-A);
a=n(1); b=n(2); c=n(3);
d=-A'*n;

abcd=[a b c d];

% Rotation to the xy plane.
% https://math.stackexchange.com/questions/1167717/transform-a-plane-to-
% the-xy-plane
% Consider correction due to user "paterry".

if (a^2+b^2) > 0 % rotation is required
    den=sqrt(a^2+b^2+c^2);
    cos_theta=c/den;
    sin_theta=sqrt(a^2+b^2)/den;

    den2=sqrt(a^2+b^2);
    u1=b/den2;
    u2=-a/den2;

    term_cos=(1-cos_theta);

    R_row1=[cos_theta+u1^2*term_cos  u1*u2*term_cos u2*sin_theta];
    R_row2=[u1*u2*term_cos cos_theta+u2^2*term_cos  -u1*sin_theta];
    R_row3=[-u2*sin_theta u1*sin_theta cos_theta];
    R10=[R_row1; R_row2; R_row3];
else % no rotation is required
    R10=eye(3);
end

xyv=R10*[XV'; YV'; ZV']; xyv=xyv';

xv=xyv(:,1);
yv=xyv(:,2);
zv=xyv(:,3);

% Check orientation polygon
[orient,signed_area] = polyorient(xv,yv);

if orient == 0
    % if orientation is clockwise, we reflect the 2D polygon w.r.t. the
    % x-axis so to map it into an equivalent one with the right orientation
    RFM=diag([1 -1 1]);
    yv=-yv;
    [orient,signed_area] = polyorient(xv,yv);
else
    RFM=eye(3);
end

if orient == 0
    warning('Some issues with orientation');
end









function [orient,signed_area] = polyorient(x,y)
%-----------------------------------------------------------------------
%   POLYORIENT Orientation of polygon
%   Returns the orientation and signed area of a 2D polygon
%
%   Syntax:
%      [orient,signed_area] = POLYORIENT(X,Y)
%
%   Inputs:
%      X, Y   Vectors with the polygon vertices
%
%   Outputs:
%      orient   Polygon orientation. 1 if the orientation is
%            counter-clockwise (direct), 0 otherwise
%      signed_area    Signed area of the polygon, negative if orientation
%               is not direct
%-----------------------------------------------------------------------
%   Examples:
%      x1 = [0 0 1 1]; y1 = [1 2 2 1];
%      x2 = [0 0 1 1]; y2 = [1 0 0 1];
%      x3 = [x1 x2];   y3 = [y1 y2];
%
%      [o1,a1] = polyorient(x1,y1) % 0, -1
%      [o2,a2] = polyorient(x2,y2) % 1,  1
%      [o3,a3] = polyorient(x3,y3) % 0,  0
%-----------------------------------------------------------------------
% Author:
% MMA 21-4-2006, mma@odyle.net
%-----------------------------------------------------------------------

signed_area=0.5* sum(x.*y([2:end 1]) - y.*x([2:end 1]));
orient = signed_area > 0;








function [XV,YV,ZV,n]=maptopolygon3(xv,yv,zv,R10,RFM)

%-----------------------------------------------------------------------
% Object:
% This routine takes a planar polygon in the 3D space whose vertices are
% (XV,YV,ZV) and maps it to a flat polygon with vertices (xv,yv,0) by a
% "rigid motion".
% The vector "zv" and the rotation matrix "R10" allow to map back the
% points.
%-----------------------------------------------------------------------
% Input:
%
% xv, yv: coordinates of the vertices of a polygon in the two dimensional
%   space that is obtained by a "rigid motion" of a polygon with
%   vertices (XV,YV,ZV); last vertex may not be repeated; they are column
%   vectors.
%
% R10,RFM: rotation and reflection matrices involved in the process.
%     It is "P=R10'*(RFM*P2+PS)" where "PS" is a certain shift, "P2" a
%     the plane xy and "P" is a point in the 3D plane.
%
%-----------------------------------------------------------------------
% Output:
%
% XV,YV,ZV: coordinates of the vertices of a polygon in the three
% dimensional space (e.g. the vertices of a facet of a tetrahedra); last
% vertex may not be repeated; they are column vectors.
%
% n: versor of outer normal to the plane containing [XV YV ZV].
%
%-----------------------------------------------------------------------
% Data:
% Revised: February 16, 2021.
%-----------------------------------------------------------------------

% k-th column determines the k-th point
P2=[xv'; yv'; zeros(size(zv'))];
PS=[zeros(size(zv')); zeros(size(zv')); zv' ];

P=R10'*(RFM*P2+PS);

XV=(P(1,:))';
YV=(P(2,:))';
ZV=(P(3,:))';

if nargout >= 4
    ee=[0;0;1];
    n=R10'*(RFM*ee); % outer normal to the facet
    n=n/norm(n); % versor of outer normal
end









function chebyshev_moms=cubature_tens_chebyshev_facet_V(nodes,weights,...
    chebyshev_indices,dbox)

%-----------------------------------------------------------------------
% Compute the cubature on the facet, having cubature nodes/weights of an
% algebraic rule with nodes "nodes" and weights "weights" of degree of
% precision "ade", of all the chebyshevs having total degree inferior or
% equal to "ade".
% As output we provide these moments in the column vector "chebyshev_moms",
% ordered as in "chebyshev_indices", with total degree as
% "chebyshev_total_degrees".
%-----------------------------------------------------------------------

X=nodes(:,1); Y=nodes(:,2); Z=nodes(:,3);

% Map to reference cube [-1,1] x [-1,1] x [-1,1]
a1=dbox(1); b1=dbox(2); A1=(a1+b1)/2; B1=(b1-a1)/2; XN=(X-A1)/B1;
a2=dbox(3); b2=dbox(4); A2=(a2+b2)/2; B2=(b2-a2)/2; YN=(Y-A2)/B2;
a3=dbox(5); b3=dbox(6); A3=(a3+b3)/2; B3=(b3-a3)/2; ZN=(Z-A3)/B3;

deg=max(chebyshev_indices(:,1));

TX=chebpolys(deg+1,XN); TY=chebpolys(deg,YN); TZ=chebpolys(deg,ZN);

chebyshev_moms=[];

FXYZN=[];

for index=1:size(chebyshev_indices,1)

    i=chebyshev_indices(index,1);
    j=chebyshev_indices(index,2);
    k=chebyshev_indices(index,3);

    % Tensorial Chebyshev polynomials x-primitive.
    switch i
        case 0
            % f=@(x,y,z) B1*x.*cos(j*acos(y)).*cos(k*acos(z));
            FXYZN(:,end+1)=B1*XN.*TY(:,j+1).*TZ(:,k+1); 
        case 1
            % f=@(x,y,z) B1*((x.^2)/2).*cos(j*acos(y)).*cos(k*acos(z));
            FXYZN(:,end+1)=B1*((XN.^2)/2).*TY(:,j+1).*TZ(:,k+1); 
        otherwise
            % f=@(x,y,z) B1*((i*cos((i+1)*acos(x))/(i^2-1)- ...
            %   x.*cos((i)*acos(x))/(i-1)).*cos(j*acos(y)).* ...
            %    cos(k*acos(z)));
            FXYZN(:,end+1)=B1*((i*TX(:,i+2)/(i^2-1)- ...
               XN.*TX(:,i+1)/(i-1)).*TY(:,j+1).* ...
                TZ(:,k+1));
    end

    % FXYZN(:,end+1)=feval(f,XN,YN,ZN); 

end

chebyshev_moms=(weights'*FXYZN)';









function xyw=rule_conversion(xyw_bar,vertices)

% INPUT:
% ade: ALGEBRAIC DEGREE OF EXACTNESS.
% vertices: 3 x 2 MATRIX OF VERTICES OF THE SIMPLEX.

% OUTPUT:
% xw: NODES AND WEIGHTS OF STROUD CONICAL RULE TYPE OF ADE ade ON THE SIMPLEX
%     WITH VERTICES vertices.

bar_coord=xyw_bar(:,1:3);
xx=bar_coord*vertices;

A=polyarea(vertices(:,1),vertices(:,2));
ww=A*xyw_bar(:,4);

xyw=[xx ww];











function T=chebpolys(deg,x)

%--------------------------------------------------------------------------
% Object:
% This routine computes the Chebyshev-Vandermonde matrix on the real line
% by recurrence.
%--------------------------------------------------------------------------
% Input:
% deg: maximum polynomial degree
% x: 1-column array of abscissas
%--------------------------------------------------------------------------
% Output:
% T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg.
%--------------------------------------------------------------------------
% Authors:
% Alvise Sommariva and Marco Vianello
% University of Padova, December 15, 2017
%--------------------------------------------------------------------------

T=zeros(length(x),deg+1);
t0=ones(length(x),1); T(:,1)=t0;
t1=x; T(:,2)=t1;

for j=2:deg
    t2=2*x.*t1-t0;
    T(:,j+1)=t2;
    t0=t1;
    t1=t2;
end




